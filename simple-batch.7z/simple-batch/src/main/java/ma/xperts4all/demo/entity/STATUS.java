package ma.xperts4all.demo.entity;

public enum STATUS {
    SENDER, RECEIVER
}
