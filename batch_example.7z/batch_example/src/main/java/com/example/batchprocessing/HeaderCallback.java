package com.example.batchprocessing;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.FlatFileHeaderCallback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.Writer;

@Component
@StepScope
public class HeaderCallback implements FlatFileHeaderCallback {

    private StepExecution stepExcecution;

    @BeforeStep
    public void setStepExecution(StepExecution stepExecution) {
        this.stepExcecution = stepExecution;
    }

    @Override
    public void writeHeader(Writer writer) throws IOException {

        System.out.println("stepExcecution.getId() : " + stepExcecution.getId());
        System.out.println("Tist Header");
        writer.write("Tist Header");
    }
}
