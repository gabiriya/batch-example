package com.example.batchprocessing;

import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;

public class PersonValidator implements Validator<Person>{

    @Override
    public void validate(Person value) throws ValidationException {
        if(value.getFirstName().startsWith("A")) {
            throw new ValidationException("First Name that begin with A are invalid"+ value);
        }
    }
}