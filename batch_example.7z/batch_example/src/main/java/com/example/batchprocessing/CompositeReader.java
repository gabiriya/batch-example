package com.example.batchprocessing;

import org.springframework.batch.item.*;

import java.util.List;
import java.util.function.BiFunction;


public class CompositeReader<T, S> implements ItemStreamReader<T> {

    private ItemStreamReader<T> primaryReader;
    private ItemStreamReader<S> complementaryReader;
    private BiFunction<T, S, T> mapper;

    public CompositeReader(ItemStreamReader<T> primaryReader, ItemStreamReader<S> complementaryReader, BiFunction<T, S, T> mapper) {
        this.primaryReader = primaryReader;
        this.complementaryReader = complementaryReader;
        this.mapper = mapper;
    }

    @Override
    public T read() throws Exception {
        T primary = primaryReader.read();
        S complementary = complementaryReader.read();

        return primary != null && complementary != null ? mapper.apply(primary, complementary) : primary;
    }

    @Override
    public void open(ExecutionContext executionContext) throws ItemStreamException {
        primaryReader.open(executionContext);
        complementaryReader.open(executionContext);
    }

    @Override
    public void update(ExecutionContext executionContext) throws ItemStreamException {

    }

    @Override
    public void close() throws ItemStreamException {
        primaryReader.close();
        complementaryReader.close();
    }
}
