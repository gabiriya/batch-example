package com.example.batchprocessing;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.builder.TaskletStepBuilder;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.batch.item.support.CompositeItemWriter;
import org.springframework.batch.item.support.builder.CompositeItemProcessorBuilder;
import org.springframework.batch.item.support.builder.CompositeItemWriterBuilder;
import org.springframework.batch.item.validator.ValidatingItemProcessor;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Bean
    public CompositeReader<Person, Person> compostiteReader(@Value("${sourcepath}") String sourcepath) {
        return new CompositeReader<>(readerFlateFile("sample-data.csv"),
                readerFlateFixedFile("sample-data.txt"),
                (p1, p2) -> {
                    p1.setFirstName(p1.getFirstName() + p2.getFirstName());
                    p1.setLastName(p1.getLastName() + p2.getLastName());
                    return p1;
                }
        );
    }

    @Bean
    public FlatFileItemReader<Person> readerFlateFile(@Value("${sourcepath}") String sourcepath) {
        return new FlatFileItemReaderBuilder<Person>()
                .name("personItemReader")
                .resource(new ClassPathResource(sourcepath))
                .delimited()
                .names(new String[]{"firt", "las"})
                .fieldSetMapper(new BeanWrapperFieldSetMapper<>() {{
                    setTargetType(Person.class);
                }})
                .build();
    }

    @Bean
    public FlatFileItemReader<Person> readerFlateFixedFile(@Value("${sourcepath}") String sourcepath) {
        return new FlatFileItemReaderBuilder<Person>()
                .name("personItemReader")
                .resource(new ClassPathResource("sample-data.txt"))
                .fixedLength()
                .addColumns(new Range(1, 6))
                .addColumns(new Range(7, 10))
                .names(new String[]{"firtname", "lastname"})
                .fieldSetMapper(new BeanWrapperFieldSetMapper<>() {{
                    setTargetType(Person.class);
                }})
                .build();
    }

    @Bean
    public JdbcCursorItemReader<Person> readerSQL(DataSource datatouse) {
        return new JdbcCursorItemReaderBuilder<Person>()
                .name("personItemReader")
                .sql("SELECT first_name, last_name FROM people")
                .dataSource(datatouse)
                .beanRowMapper(Person.class)
                .build();
    }

    @Bean
    public ValidatingItemProcessor<Person> itemValidator() {
        ValidatingItemProcessor<Person> validatingItemProcessor = new ValidatingItemProcessor<>();
        validatingItemProcessor.setValidator(new PersonValidator());
        validatingItemProcessor.setFilter(false);
        return validatingItemProcessor;
    }

    @Bean
    public PersonItemProcessor processor() {
        return new PersonItemProcessor();
    }

    @Bean
    public CompositeItemProcessor<Person, Person> compositeProcessor() {
        return new CompositeItemProcessorBuilder<Person, Person>()
                .delegates(itemValidator(), processor())
                .build();
    }

    @Bean
    public JdbcBatchItemWriter<Person> writerSQL(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<Person>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO people (first_name, last_name) VALUES (:firstName, :lastName)")
                .dataSource(dataSource)
                .build();
    }

    @Bean
    public FlatFileItemWriter<Person> writerFlatFile(@Value("${outputpath}") String outputPath) {
        return new FlatFileItemWriterBuilder<Person>()
                .name("personItemWriter")
                .append(true)
                .resource(new FileSystemResource(outputPath))
                .delimited()
                .names(new String[]{"firstName", "lastName"})
                .build();
    }

    @Bean
    public FlatFileItemWriter<Person> writerFlatFixedFile(@Value("${outputpath}") String outputPath) {
        return new FlatFileItemWriterBuilder<Person>()
                .name("personItemWriter")
                .resource(new FileSystemResource(outputPath + "_fixed"))
                .formatted()
                .format("%6s%4s")
                .names(new String[]{"firstName", "lastName"})
                /*
                .headerCallback(writer-> {
                    System.out.println("Tist Header");
                    writer.write("Tist Header");
                })
                .footerCallback(writer-> {
                    System.out.println("Tist Footer");
                    writer.write("Tist Footer");
                })
                */
                .build();
    }

    @Bean
    public CompositeItemWriter<Person> compostiteWriter(@Value("${outputpath}") String outputPath) {
        return new CompositeItemWriterBuilder<Person>()
                .delegates(List.of(writerFlatFile(outputPath), writerFlatFixedFile(outputPath + "_fixed")))
                .build();
    }

    @Bean
    public Job job1(JobCompletionNotificationListener listener, Step step1) {

        return jobBuilderFactory.get("importUserJob")
                .incrementer(new RunIdIncrementer())
                //.listener(listener)
                .flow(step1)
                .end()
                .build();
    }

    @ConditionalOnProperty(name = "jobs.name", havingValue = "Job1")
    @Bean
    public Step step1(@Value("${sourcepath}") String sourcepath,
                      @Value("${chunksize}") Integer chunksize,
                      @Value("${outputpath}") String outputPath) {
        return stepBuilderFactory.get("step1")
                .<Person, Person>chunk(chunksize)
                .reader(readerFlateFile(sourcepath))
                .processor(processor())
                .writer(writerFlatFixedFile(outputPath))
                .build();
    }

    @ConditionalOnProperty(name = "jobs.name", havingValue = "Job2")
    @Bean
    public Step step2(DataSource dataSource, @Value("${outputpath}") String outputPath, @Value("${chunksize}") Integer chunksize) {
        return stepBuilderFactory.get("step1")
                .<Person, Person>chunk(chunksize)
                .reader(readerSQL(dataSource))
                .processor(processor())
                .writer(writerFlatFile(outputPath))
                .build();
    }

    @ConditionalOnProperty(name = "jobs.name", havingValue = "Job3")
    @Bean
    public Step step3(DataSource dataSource, @Value("${sourcepath}") String sourcepath, @Value("${outputpath}") String outputPath, @Value("${chunksize}") Integer chunksize) {
        return stepBuilderFactory.get("step1")
                .<Person, Person>chunk(chunksize)
                .reader(readerFlateFixedFile(sourcepath))
                .processor(compositeProcessor())
                .writer(writerFlatFixedFile(outputPath))
                .build();
    }

    @ConditionalOnProperty(name = "jobs.name", havingValue = "Job4")
    @Bean
    public Step step4(DataSource dataSource, @Value("${sourcepath}") String sourcepath, @Value("${outputpath}") String outputPath, @Value("${chunksize}") Integer chunksize) {
        return stepBuilderFactory.get("step1")
                .<Person, Person> chunk(chunksize)
                .reader(compostiteReader(sourcepath))
                .processor(compositeProcessor())
                .writer(compostiteWriter(outputPath))
                .build();
    }

    @Bean
    public Tasklet tasklet(@Value("${sourcepath}") String sourcepath, @Value("${outputpath}") String outputPath) {
        return (stepContribution, chunkContext) -> {
            FlatFileItemReader<Person> reader = readerFlateFile(sourcepath);
            reader.open(chunkContext.getStepContext().getStepExecution().getExecutionContext());

            List<Person> pp = new ArrayList<>();
            Person p = null;
            do {
                p = reader.read();
                pp.add(p);
            } while(p != null);

            reader.close();

            FlatFileItemWriter<Person> writer = writerFlatFile(outputPath);
            writer.open(chunkContext.getStepContext().getStepExecution().getExecutionContext());

            writer.write(pp);
            writer.close();

            System.out.println("chunky");
            return null;
        };
    }

    @ConditionalOnProperty(name = "jobs.name", havingValue = "Job5")
    @Bean
    public Step step5(DataSource dataSource, @Value("${sourcepath}") String sourcepath, @Value("${outputpath}") String outputPath, @Value("${chunksize}") Integer chunksize) {

        return stepBuilderFactory.get("step1")
                .tasklet(tasklet(sourcepath, outputPath))
                .build();
    }
}