package com.example.batchprocessing;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

public class FlatFileReaderTest {

    @Test
    public void testPersoneCsvReader() throws Exception {
        String outputFile = "sample-data.csv";

        FlatFileItemReader<Person> reader = new BatchConfiguration().readerFlateFile(outputFile);

        ExecutionContext executionContext = new ExecutionContext();
        reader.open(executionContext);
        Person p = reader.read();
        reader.close();

        Assert.assertEquals("Jill", p.getFirstName());
        Assert.assertEquals("Doe", p.getLastName());
    }
}
