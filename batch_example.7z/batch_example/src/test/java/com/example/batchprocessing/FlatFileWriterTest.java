package com.example.batchprocessing;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.FlatFileItemWriter;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

public class FlatFileWriterTest {

    @Test
    public void testPersoneFixedWriter() throws Exception {
        /*String outputFile = "target/test-outputs/test-sample-data-output.fixed";

        FlatFileItemWriter<Person> writer = new BatchConfiguration().writerFlatFixedFile(new HeaderCallback(), outputFile);

        ExecutionContext executionContext = new ExecutionContext();
        writer.open(executionContext);
        writer.write(Arrays.asList(new Person("1", "1"), new Person("2", "2"), new Person("3", "3")));
        writer.close();

        byte[] outputFileBytes = Files.readAllBytes(Paths.get(outputFile));

        String outputFileContent = new String(outputFileBytes, StandardCharsets.UTF_8);
        Assert.assertEquals("Tist Header\r\n     1   1\r\n     2   2\r\n     3   3\r\nTist Footer", outputFileContent);*/
    }
}
